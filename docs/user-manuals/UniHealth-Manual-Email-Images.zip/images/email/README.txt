UniHealth User Manual — Email image bundle
============================================

Generated: 2026-06-11T05:04:17.372Z

Use WebP images in modern email clients; attach JPEG where WebP is unsupported.
Total WebP bundle: 432.2 KB (recommended attachment set)
Total JPEG bundle: 678.0 KB
Optimized manual PNGs: 2.71 MB (in ../ for HTML manual)

Attach UniHealth-Web-User-Manual.html + images/email/*.webp
Or zip this email/ folder (~432.2 KB WebP).
